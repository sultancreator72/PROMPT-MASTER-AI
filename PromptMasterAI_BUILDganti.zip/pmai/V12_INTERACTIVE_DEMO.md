# PROMPT MASTER AI V12 — Interactive Demo

V12 makes the first-run experience easier to understand. The Dashboard contains an embedded offline demo video and a **Coba Demo** action.

## Demo flow
1. Dashboard opens with the demo video.
2. User taps **Coba Demo**.
3. The app loads a sample Affiliate Pro project.
4. The sample has approved scenes for Hook, Product Showcase, Benefit/Demo, and CTA.
5. User can inspect, edit, generate a Master Prompt, or connect the production backend.

The demo data is local and does not consume provider credits.
