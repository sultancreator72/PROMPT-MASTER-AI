# PROMPT MASTER AI — Backend V9

V9 adds the **Auto Film Assembler** on top of the real Google Veo 3.1 adapter.

## Production flow
Android → HTTPS backend → approved scenes → Veo 3.1 per shot → downloaded MP4s → FFmpeg assembly → final MP4.

## API
- `GET /health`
- `POST /v1/films` — submit all approved scenes
- `GET /v1/films/:filmId` — poll film progress/result
- `POST /v1/films/:filmId/cancel` — mark the film cancelled
- `POST /v1/jobs` and `GET /v1/jobs/:jobId` remain available for single-shot compatibility.

## Environment
Set `GEMINI_API_KEY`, `BACKEND_API_TOKEN`, `PUBLIC_BASE_URL`, and `MEDIA_DIR`. FFmpeg must be installed on the server and available as `ffmpeg` on PATH.

## Continuity
The same lock manifest and continuity contract are attached to every approved scene. The backend rejects unapproved scenes and only accepts Veo-compatible 4/6/8 second shot durations.

## Production hardening still required
For a public multi-user deployment, replace in-memory Maps with a persistent database/queue, add object storage/CDN, user authentication/authorization, quotas and billing, rate limiting, retries, cleanup/retention, monitoring, HTTPS, secret management, and Play Integrity on Android.

Never put provider API keys in the Android APK.
