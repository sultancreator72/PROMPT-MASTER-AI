import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
const execFileP = promisify(execFile);

export class VideoProvider {
  constructor(name = "unconfigured") { this.name = name; }
  async submit() { throw new Error(`Provider ${this.name} is not configured`); }
  async status() { throw new Error("Provider status not configured"); }
  async extendToTenSeconds(sourcePath, prompt) {
    this.assertConfigured();
    if (!sourcePath) throw new Error("extension_source_missing");
    const bytes = await fs.readFile(sourcePath);
    const instance = { prompt, video: { inlineData: { mimeType: "video/mp4", data: bytes.toString("base64") } } };
    const parameters = { numberOfVideos: 1, resolution: "720p", durationSeconds: "8" };
    const r = await fetch(`${this.baseUrl}/models/${this.model}:predictLongRunning`, {
      method: "POST",
      headers: { "x-goog-api-key": this.apiKey, "content-type": "application/json" },
      body: JSON.stringify({ instances: [instance], parameters })
    });
    const data = await r.json();
    if (!r.ok || !data.name) throw new Error(data?.error?.message || "Veo extension submission failed");
    let op = data.name;
    while (true) {
      await new Promise(r => setTimeout(r, 5000));
      const sr = await fetch(`${this.baseUrl}/${op}`, { headers: { "x-goog-api-key": this.apiKey } });
      const sd = await sr.json();
      if (!sr.ok) throw new Error(sd?.error?.message || "Veo extension status failed");
      if (!sd.done) continue;
      if (sd.error) throw new Error(sd.error.message || "veo_extension_error");
      const uri = sd?.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri;
      if (!uri) throw new Error("extension_video_uri_missing");
      const vr = await fetch(uri, { headers: { "x-goog-api-key": this.apiKey } });
      if (!vr.ok) throw new Error(`extension_video_download_failed_${vr.status}`);
      const bytes = Buffer.from(await vr.arrayBuffer());
      await fs.mkdir(this.mediaDir, { recursive: true });
      const raw = path.join(this.mediaDir, `${crypto.randomUUID()}-extended.mp4`);
      const outName = `${crypto.randomUUID()}-10s.mp4`;
      const out = path.join(this.mediaDir, outName);
      await fs.writeFile(raw, bytes);
      // Veo extension adds 7 seconds to the original 8-second shot. Keep the
      // first 10 seconds as the user-facing 10s scene output.
      await execFileP("ffmpeg", ["-y", "-i", raw, "-t", "10", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out], { maxBuffer: 1024*1024*8 });
      await fs.rm(raw, { force: true });
      return { status: "completed", progress: 100, resultUrl: `/media/${outName}` };
    }
  }

  async cancel() { return { cancelled: false }; }
}

/**
 * Real Google Veo 3.1 adapter.
 * The Gemini/Veo API key exists only on the backend.
 * V8 intentionally generates one Veo shot per production job; longer films are
 * represented as approved scene jobs and can be stitched by a future render worker.
 */
export class GeminiVeoProvider extends VideoProvider {
  constructor() {
    super("gemini-veo-3.1");
    this.apiKey = process.env.GEMINI_API_KEY || "";
    this.model = process.env.VEO_MODEL || "veo-3.1-generate-preview";
    this.baseUrl = process.env.GEMINI_BASE_URL || "https://generativelanguage.googleapis.com/v1beta";
    this.mediaDir = process.env.MEDIA_DIR || path.resolve(process.cwd(), "media");
  }

  assertConfigured() {
    if (!this.apiKey) throw new Error("GEMINI_API_KEY is not configured on the server");
  }

  async submit({ prompt, durationSeconds = 8, referenceImages = [], aspectRatio = "9:16", resolution = "720p" }) {
    this.assertConfigured();
    const refs = (referenceImages || []).slice(0, 3).filter(x => x?.data && x?.mimeType);
    const instance = { prompt };
    if (refs.length) {
      instance.referenceImages = refs.map(x => ({ image: { inlineData: { mimeType: x.mimeType, data: x.data } } }));
    }
    const duration = Number(durationSeconds) === 10 ? 8 : ([4, 6, 8].includes(Number(durationSeconds)) ? Number(durationSeconds) : 8);
    const parameters = { aspectRatio: aspectRatio === "16:9" ? "16:9" : "9:16", durationSeconds: String(duration), resolution: resolution === "1080p" ? "1080p" : "720p", numberOfVideos: 1 };
    const r = await fetch(`${this.baseUrl}/models/${this.model}:predictLongRunning`, {
      method: "POST",
      headers: { "x-goog-api-key": this.apiKey, "content-type": "application/json" },
      body: JSON.stringify({ instances: [instance], parameters })
    });
    const data = await r.json();
    if (!r.ok || !data.name) throw new Error(data?.error?.message || "Veo submission failed");
    return { providerJobId: data.name };
  }

  async status(providerJobId) {
    this.assertConfigured();
    const r = await fetch(`${this.baseUrl}/${providerJobId}`, { headers: { "x-goog-api-key": this.apiKey } });
    const data = await r.json();
    if (!r.ok) throw new Error(data?.error?.message || "Veo status failed");
    if (!data.done) return { status: "running", progress: 60 };
    if (data.error) return { status: "failed", progress: 0, error: data.error.message || "veo_error" };
    const uri = data?.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri;
    if (!uri) return { status: "failed", progress: 0, error: "video_uri_missing" };
    const fileName = `${crypto.randomUUID()}.mp4`;
    await fs.mkdir(this.mediaDir, { recursive: true });
    const out = path.join(this.mediaDir, fileName);
    const vr = await fetch(uri, { headers: { "x-goog-api-key": this.apiKey } });
    if (!vr.ok) throw new Error(`video_download_failed_${vr.status}`);
    const bytes = Buffer.from(await vr.arrayBuffer());
    await fs.writeFile(out, bytes);
    return { status: "completed", progress: 100, resultUrl: `/media/${fileName}`, providerVideoUri: uri, providerVideoPath: out };
  }


  async cancel() {
    // Gemini LRO cancellation is provider/model dependent. We expose a safe local cancellation state.
    return { cancelled: true, note: "Provider operation may continue server-side; result is ignored." };
  }
}
