import http from "node:http";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { GeminiVeoProvider } from "./provider.mjs";

const port = Number(process.env.PORT || 8787);
const apiToken = process.env.BACKEND_API_TOKEN || "";
const jobs = new Map();
const queue = [];
const MAX_CONCURRENT_FILMS = Math.max(1, Number(process.env.MAX_CONCURRENT_FILMS || 1));
let activeFilms = 0;
const STATE_FILE = process.env.STATE_FILE || path.resolve(process.cwd(), "data", "jobs.json");
const provider = new GeminiVeoProvider();
const filmJobs = new Map();

async function persistState() {
  await fs.promises.mkdir(path.dirname(STATE_FILE), {recursive:true});
  const snapshot = {
    jobs:[...jobs.values()].map(j=>({...j, prompt:undefined, referenceImages:undefined})),
    films:[...filmJobs.values()].map(j=>({...j, basePrompt:undefined, referenceImages:undefined}))
  };
  await fs.promises.writeFile(STATE_FILE, JSON.stringify(snapshot), "utf8");
}
async function loadState() {
  try {
    const raw=await fs.promises.readFile(STATE_FILE,"utf8"); const data=JSON.parse(raw);
    for (const j of data.jobs||[]) jobs.set(j.id,j);
    for (const j of data.films||[]) filmJobs.set(j.id,j);
  } catch {}
}
function enqueueFilm(job) { queue.push(job); void pumpQueue(); }
async function pumpQueue() {
  while(activeFilms < MAX_CONCURRENT_FILMS && queue.length) {
    const job=queue.shift(); if(!job || job.status==="cancelled") continue;
    activeFilms++; void runFilm(job).finally(()=>{activeFilms--; void persistState(); void pumpQueue();});
  }
}
const mediaDir = process.env.MEDIA_DIR || path.resolve(process.cwd(), "media");

function json(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {"content-type":"application/json; charset=utf-8", "cache-control":"no-store"});
  res.end(data);
}
function authorized(req) {
  if (!apiToken) return process.env.NODE_ENV !== "production";
  return req.headers.authorization === `Bearer ${apiToken}`;
}
function body(req) { return new Promise((resolve,reject)=>{ let raw=""; req.on("data",c=>{ raw+=c; if(raw.length>12_000_000) req.destroy(); }); req.on("end",()=>{ try{resolve(raw?JSON.parse(raw):{});}catch(e){reject(e);} }); req.on("error",reject); }); }
function validate(input) {
  if(!input || typeof input !== "object") return "Invalid request";
  if(!input.prompt || typeof input.prompt !== "string") return "prompt is required";
  if(input.prompt.length > 100000) return "prompt too long";
  if(input.lockManifest && typeof input.lockManifest !== "object") return "lockManifest must be an object";
  if(input.referenceImages && (!Array.isArray(input.referenceImages) || input.referenceImages.length > 3)) return "referenceImages must contain at most 3 images";
  for (const image of input.referenceImages || []) {
    if (!image.data || !image.mimeType || !/^image\/(png|jpeg|jpg|webp)$/i.test(image.mimeType)) return "unsupported reference image";
    if (typeof image.data !== "string" || image.data.length > 7_000_000) return "reference image too large";
  }
  return null;
}
function publicJob(job){ return {jobId:job.id,status:job.status,progress:job.progress,resultUrl:job.resultUrl||null,error:job.error||null,createdAt:job.createdAt,provider:job.provider}; }

function publicFilm(job){ return {filmId:job.id,status:job.status,progress:job.progress,resultUrl:job.resultUrl||null,error:job.error||null,createdAt:job.createdAt,scenes:job.scenes.map(s=>({number:s.number,status:s.status,progress:s.progress,durationSeconds:s.durationSeconds}))}; }
function validateFilm(input) {
  if(!input || typeof input !== "object") return "Invalid request";
  if(!Array.isArray(input.scenes) || input.scenes.length < 1 || input.scenes.length > 20) return "scenes must contain 1-20 items";
  for (const s of input.scenes) {
    if(!s || typeof s !== "object" || !s.approved) return "all submitted scenes must be approved";
    if(!s.action && !s.title) return "scene title or action is required";
    if(![8,10].includes(Number(s.durationSeconds))) return "scene duration must be 8 or 10 seconds";
  }
  return validate(input);
}
async function runFilm(job) {
  try {
    job.status="running"; job.progress=1; await persistState();
    const completed=[];
    for (let i=0;i<job.scenes.length;i++) {
      const scene=job.scenes[i];
      if (job.status === "cancelled") throw new Error("cancelled_by_user");
      scene.status="running"; scene.progress=5;
      const continuity = `\nCONTINUITY CONTRACT: preserve the exact locked identity across every shot. Scene ${scene.number}/${job.scenes.length}. Never change product design, character identity, wardrobe, location, props, colors, or story facts unless explicitly listed in allowedChanges.\n`;
      const requestedDuration=Number(scene.durationSeconds);
      const submitted=await provider.submit({prompt:job.basePrompt+continuity+`\nAPPROVED SCENE ${scene.number}: ${scene.title}\nACTION/DIALOGUE: ${scene.action}\nCAMERA: ${scene.camera}\nTRANSITION INTENT: ${scene.transition}\n`,lockManifest:job.lockManifest,durationSeconds:scene.durationSeconds,referenceImages:job.referenceImages,aspectRatio:job.aspectRatio,resolution:job.resolution});
      scene.providerJobId=submitted.providerJobId;
      let status="running";
      while(status === "running" || status === "queued") {
        const st=await provider.status(scene.providerJobId);
        status=st.status; scene.progress=st.progress ?? scene.progress;
        if(status === "completed") { scene.resultUrl=st.resultUrl; scene.providerVideoUri=st.providerVideoUri || null; scene.providerVideoPath=st.providerVideoPath || null; completed.push(st.resultUrl); scene.status="completed"; scene.progress=100; }
        else if(status === "failed") throw new Error(`scene_${scene.number}:${st.error||"provider_error"}`);
        else await new Promise(r=>setTimeout(r,4000));
      }
      if (requestedDuration === 10) {
        scene.status="extending"; scene.progress=70;
        if (!scene.providerVideoPath) throw new Error(`scene_${scene.number}:extension_source_missing`);
        const extended = await provider.extendToTenSeconds(scene.providerVideoPath, job.basePrompt + continuity + `\nCONTINUE SCENE ${scene.number}: continue the exact motion, framing logic, character identity, wardrobe, location and audio naturally for the extension; do not introduce a new scene.`);
        scene.resultUrl = extended.resultUrl;
        completed[completed.length-1] = extended.resultUrl;
      }
      job.progress=Math.max(1,Math.round(((i+1)/job.scenes.length)*80));
    }
    if (job.status === "cancelled") throw new Error("cancelled_by_user");
    const inputs=completed.map(u=>path.join(mediaDir,path.basename(u))).filter(Boolean);
    if(inputs.length!==job.scenes.length) throw new Error("missing_scene_media");
    await fs.mkdir(mediaDir,{recursive:true});
    const concatFile=path.join(mediaDir,`${job.id}.concat.txt`);
    await fs.writeFile(concatFile,inputs.map(x=>`file '${x.replaceAll("'","'\\''")}'`).join("\n"));
    const out=path.join(mediaDir,`${job.id}.mp4`);
    const {execFile}=await import("node:child_process");
    const {promisify}=await import("node:util");
    const execFileP=promisify(execFile);
    await execFileP("ffmpeg",["-y","-f","concat","-safe","0","-i",concatFile,"-c:v","libx264","-preset","veryfast","-crf","20","-c:a","aac","-b:a","192k","-movflags","+faststart",out],{maxBuffer:1024*1024*8});
    await fs.rm(concatFile,{force:true});
    if (job.status === "cancelled") { await fs.rm(out,{force:true}); throw new Error("cancelled_by_user"); }
    job.status="completed"; job.progress=100; job.resultUrl=`${process.env.PUBLIC_BASE_URL||""}/media/${path.basename(out)}`; await persistState();
  } catch(e) { if (job.status !== "cancelled") { job.status="failed"; job.error=e?.message||"film_render_failed"; } await persistState(); }
}

async function refresh(job) {
  if (!job.providerJobId || !["queued","running"].includes(job.status)) return;
  try {
    const s = await provider.status(job.providerJobId);
    job.status = s.status; job.progress = s.progress ?? job.progress; job.resultUrl = s.resultUrl ? `${process.env.PUBLIC_BASE_URL || ""}${s.resultUrl}` : null; job.error = s.error ?? null;
  } catch (e) { job.status="failed"; job.error=e?.message || "provider_error"; }
}

const server=http.createServer(async (req,res)=>{
  try {
    const url=new URL(req.url, `http://${req.headers.host||"localhost"}`);
    if(req.method==="GET" && url.pathname==="/health") return json(res,200,{ok:true,service:"prompt-master-ai-backend",version:"13.5",provider:provider.name,configured:Boolean(process.env.GEMINI_API_KEY),assembler:"ffmpeg",activeFilms,queuedFilms:queue.length});
    if(req.method==="GET" && url.pathname.startsWith("/media/")) {
      const name=path.basename(url.pathname);
      if(name !== url.pathname.slice("/media/".length)) return json(res,400,{error:"invalid_media_path"});
      const file=path.join(mediaDir,name);
      if(!fs.existsSync(file)) return json(res,404,{error:"media_not_found"});
      res.writeHead(200,{"content-type":"video/mp4","cache-control":"private, max-age=3600"});
      return fs.createReadStream(file).pipe(res);
    }
    if(!authorized(req)) return json(res,401,{error:"unauthorized"});
    if(req.method==="POST" && url.pathname==="/v1/jobs") {
      const input=await body(req); const error=validate(input); if(error) return json(res,400,{error});
      const id=crypto.randomUUID();
      const job={id,status:"queued",createdAt:new Date().toISOString(),progress:0,prompt:input.prompt,lockManifest:input.lockManifest||{},provider:provider.name};
      jobs.set(id,job);
      await persistState();
      const submitted=await provider.submit({prompt:job.prompt,lockManifest:job.lockManifest,durationSeconds:input.durationSeconds,referenceImages:input.referenceImages,aspectRatio:input.aspectRatio,resolution:input.resolution});
      job.providerJobId=submitted.providerJobId; job.status="running"; job.progress=5; await persistState();
      return json(res,202,publicJob(job));
    }
    if(req.method==="POST" && url.pathname==="/v1/films") {
      const input=await body(req); const error=validateFilm(input); if(error) return json(res,400,{error});
      const id=crypto.randomUUID();
      const job={id,status:"queued",createdAt:new Date().toISOString(),progress:0,basePrompt:input.prompt,lockManifest:input.lockManifest||{},referenceImages:input.referenceImages||[],aspectRatio:input.aspectRatio||"9:16",resolution:input.resolution||"720p",resultUrl:null,error:null,scenes:input.scenes.map((s,i)=>({number:s.number||i+1,title:s.title||`Scene ${i+1}`,action:s.action||"",camera:s.camera||"Cinematic shot",transition:s.transition||"Cut",durationSeconds:Number(s.durationSeconds),approved:true,status:"queued",progress:0}))};
      filmJobs.set(id,job); await persistState(); enqueueFilm(job); return json(res,202,publicFilm(job));
    }
    const fm=url.pathname.match(/^\/v1\/films\/([^/]+)$/);
    if(fm && req.method==="GET") { const job=filmJobs.get(fm[1]); if(!job) return json(res,404,{error:"film_not_found"}); return json(res,200,publicFilm(job)); }
    const fc=url.pathname.match(/^\/v1\/films\/([^/]+)\/cancel$/);
    if(fc && req.method==="POST") { const job=filmJobs.get(fc[1]); if(!job) return json(res,404,{error:"film_not_found"}); job.status="cancelled"; job.error="cancelled_by_user"; await persistState(); return json(res,200,publicFilm(job)); }
    const m=url.pathname.match(/^\/v1\/jobs\/([^/]+)$/);
    if(m && req.method==="GET") { const job=jobs.get(m[1]); if(!job) return json(res,404,{error:"job_not_found"}); await refresh(job); return json(res,200,publicJob(job)); }
    const c=url.pathname.match(/^\/v1\/jobs\/([^/]+)\/cancel$/);
    if(c && req.method==="POST") { const job=jobs.get(c[1]); if(!job) return json(res,404,{error:"job_not_found"}); await provider.cancel(job.providerJobId); job.status="cancelled"; job.progress=0; await persistState(); return json(res,200,publicJob(job)); }
    return json(res,404,{error:"not_found"});
  } catch(e) { return json(res,500,{error:e?.message || "internal_error"}); }
});
await loadState();
server.listen(port,()=>console.log(`Prompt Master AI backend v10 listening on :${port}`));
