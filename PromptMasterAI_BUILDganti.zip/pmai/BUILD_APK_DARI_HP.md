# Build APK dari HP

Project V13.5 ini tetap mempertahankan source aplikasi. Untuk menghasilkan APK dari HP tanpa PC, gunakan GitHub Actions.

1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini (jangan upload ZIP sebagai satu-satunya file).
3. Buka tab **Actions**.
4. Pilih workflow **Build Prompt Master AI APK**.
5. Tekan **Run workflow**.
6. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
7. Download `PromptMasterAI-V13.5-debug-APK.zip`.
8. Ekstrak ZIP tersebut di HP. Di dalamnya ada `app-debug.apk`.
9. Ketuk APK dan izinkan instalasi dari sumber yang diizinkan Android bila diminta.

Catatan: APK debug dibuat oleh GitHub Actions; backend production masih mengikuti konfigurasi project. Flow/fitur aplikasi tidak diubah oleh workflow ini.
