#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GRADLE_VERSION="9.6.0"
DIST_DIR="${ROOT}/.gradle-dist"
GRADLE_HOME="${DIST_DIR}/gradle-${GRADLE_VERSION}"
if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java is required (JDK 17+)." >&2
  exit 1
fi
if [ ! -x "${GRADLE_HOME}/bin/gradle" ]; then
  mkdir -p "${DIST_DIR}"
  ARCHIVE="${DIST_DIR}/gradle-${GRADLE_VERSION}-bin.zip"
  URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
  echo "Downloading Gradle ${GRADLE_VERSION}..."
  if command -v curl >/dev/null 2>&1; then
    curl -fL "$URL" -o "$ARCHIVE"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$ARCHIVE" "$URL"
  else
    echo "ERROR: curl or wget is required to download Gradle." >&2
    exit 1
  fi
  rm -rf "${GRADLE_HOME}"
  unzip -q "$ARCHIVE" -d "$DIST_DIR"
fi
exec "${GRADLE_HOME}/bin/gradle" -p "$ROOT" :app:assembleDebug "$@"
