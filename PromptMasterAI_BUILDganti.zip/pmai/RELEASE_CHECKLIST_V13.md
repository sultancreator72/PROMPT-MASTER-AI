# PROMPT MASTER AI V13.0 — Release Checklist

## Included
- Interactive offline dashboard demo video
- Five-step guided demo: Product → Character → Storyboard → Generate → Finished
- Affiliate Pro Mode
- Product Master Lock
- Character / Location / Object / Story locks
- Scene approval workflow
- Production job queue architecture
- Backend/provider separation
- Auto film assembly architecture
- Recovery/backup
- Completion notification text

## Required before production launch
1. Build signed release APK/AAB with Android Studio/Gradle.
2. Run unit, UI, backend, and end-to-end tests.
3. Configure HTTPS, authentication, quotas, database, durable queue and object storage.
4. Configure the chosen AI video provider on the server only; never embed provider secrets in the APK.
5. Add monitoring, rate limiting, abuse controls, cost controls and audit logs.
6. Test interrupted jobs, retries, duplicate taps, provider errors and partial scene failures.
7. Test Play Store privacy, data-safety and content-policy requirements.
