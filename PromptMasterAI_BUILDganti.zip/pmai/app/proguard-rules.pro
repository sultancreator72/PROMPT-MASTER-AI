# PROMPT MASTER AI release hardening.
# Do not keep the entire application package: that would weaken obfuscation.
# Keep only rules required by libraries or added by future integrations.
# Never store API secrets in the Android client.
