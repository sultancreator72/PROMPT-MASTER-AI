package com.jokohudi.promptmasterai.network

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minimal provider-neutral client. Keep credentials out of this class/APK. */
object ProductionApi {
    data class Job(val id: String, val status: String, val progress: Int, val resultUrl: String?)

    fun submit(baseUrl: String, prompt: String, lockManifest: JSONObject, durationSeconds: Int, bearerToken: String? = null): Job {
        val conn = URL(baseUrl.trimEnd('/') + "/v1/jobs").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        if (!bearerToken.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer $bearerToken")
        val payload = JSONObject().apply {
            put("prompt", prompt)
            put("lockManifest", lockManifest)
            put("durationSeconds", durationSeconds)
        }.toString()
        conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        return parse(conn.inputStream.bufferedReader().use { it.readText() })
    }

    fun status(baseUrl: String, jobId: String, bearerToken: String? = null): Job {
        val conn = URL(baseUrl.trimEnd('/') + "/v1/jobs/" + jobId).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        if (!bearerToken.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer $bearerToken")
        return parse(conn.inputStream.bufferedReader().use { it.readText() })
    }

    private fun parse(text: String): Job {
        val o = JSONObject(text)
        return Job(o.optString("jobId"), o.optString("status"), o.optInt("progress"), o.optString("resultUrl").ifBlank { null })
    }
}
