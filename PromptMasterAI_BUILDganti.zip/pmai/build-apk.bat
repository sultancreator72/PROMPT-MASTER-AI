@echo off
setlocal
set ROOT=%~dp0
set GRADLE_VERSION=9.6.0
set DIST_DIR=%ROOT%.gradle-dist
set GRADLE_HOME=%DIST_DIR%\gradle-%GRADLE_VERSION%
if exist "%GRADLE_HOME%\bin\gradle.bat" goto build
if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
set ARCHIVE=%DIST_DIR%\gradle-%GRADLE_VERSION%-bin.zip
echo Downloading Gradle %GRADLE_VERSION%...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ARCHIVE%'"
powershell -NoProfile -Command "Expand-Archive -Path '%ARCHIVE%' -DestinationPath '%DIST_DIR%' -Force"
:build
call "%GRADLE_HOME%\bin\gradle.bat" -p "%ROOT%" :app:assembleDebug %*
endlocal
