@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Use Android Studio/Gradle 9.6.0, or run the included GitHub Actions workflow.
exit /b 1
