# PROMPT MASTER AI V10.0

Production-grade continuation of V9.

Core principle:
> AI boleh kreatif, tetapi tidak boleh mengubah sesuatu yang tidak diperintahkan pengguna.

V10 focuses on durable job metadata and controlled production concurrency while preserving Product/Character/Location/Object/Story locks and the Auto Film Assembler.

This package is source code. It is not a verified APK/AAB build.


## V12 — Interactive Demo Dashboard
- Embedded offline demo video on Dashboard.
- Coba Demo button loads a ready-to-review Affiliate Pro sample project.
- Sample includes 4 approved scenes: Hook, Product Showcase, Benefit/Demo, CTA.
- Demo does not call an AI provider; it is a safe local walkthrough.
